package com.fares.quickmathtapper

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle

class ScreenCaptureActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val capIntent = intent.getParcelableExtra<Intent>("capIntent")
        if (capIntent != null) {
            startActivityForResult(capIntent, 9001)
        } else {
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9001) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = if (resultCode == RESULT_OK && data != null) mpm.getMediaProjection(resultCode, data) else null
            ScreenCapturer.setProjection(mp, this)
        }
        finish()
    }
}
