package com.fares.quickmathtapper

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class RectEditorView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val pFill = Paint().apply { color = 0x3300C853; style = Paint.Style.FILL }
    private val pStroke = Paint().apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 3f }
    private val pHandle = Paint().apply { color = Color.YELLOW; style = Paint.Style.FILL }
    private val pLabel = Paint().apply { color = Color.WHITE; textSize = 36f }

    private val rects = arrayOf(RectF(), RectF(), RectF(), RectF(), RectF())
    private val labels = arrayOf("Q","A1","A2","A3","A4")

    private var activeIdx = -1
    private var mode: Mode = Mode.NONE
    private var downX = 0f
    private var downY = 0f
    private val HANDLE_SIZE = 28f

    enum class Mode { NONE, MOVE, RESIZE }

    init {
        // Load from prefs or set defaults
        val p = context.getSharedPreferences("roi", Context.MODE_PRIVATE)
        fun getR(key: String, def: RectF) = RectF(
            p.getInt("${key}_x", def.left.toInt()).toFloat(),
            p.getInt("${key}_y", def.top.toInt()).toFloat(),
            p.getInt("${key}_x", def.left.toInt()).toFloat() + p.getInt("${key}_w", def.width().toInt()),
            p.getInt("${key}_y", def.top.toInt()).toFloat() + p.getInt("${key}_h", def.height().toInt())
        )
        val w = resources.displayMetrics.widthPixels.toFloat()
        rects[0] = getR("q", RectF(0.08f*w, 420f, 0.92f*w, 580f))
        rects[1] = getR("a1", RectF(0.12f*w, 700f, 0.96f*w, 820f))
        rects[2] = getR("a2", RectF(0.12f*w, 880f, 0.96f*w, 1000f))
        rects[3] = getR("a3", RectF(0.12f*w, 1060f,0.96f*w, 1180f))
        rects[4] = getR("a4", RectF(0.12f*w, 1240f,0.96f*w, 1360f))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (i in rects.indices) {
            val r = rects[i]
            canvas.drawRect(r, pFill)
            canvas.drawRect(r, pStroke)
            canvas.drawText(labels[i], r.left + 8, r.top - 8, pLabel)
            // handles: draw small squares at corners
            drawHandle(canvas, r.left, r.top)
            drawHandle(canvas, r.right, r.top)
            drawHandle(canvas, r.left, r.bottom)
            drawHandle(canvas, r.right, r.bottom)
        }
    }

    private fun drawHandle(c: Canvas, x: Float, y: Float) {
        c.drawRect(x - HANDLE_SIZE, y - HANDLE_SIZE, x + HANDLE_SIZE, y + HANDLE_SIZE, pHandle)
        c.drawRect(x - HANDLE_SIZE, y - HANDLE_SIZE, x + HANDLE_SIZE, y + HANDLE_SIZE, pStroke)
    }

    private fun hitTest(x: Float, y: Float): Pair<Int, Boolean> {
        // returns (index, isHandle)
        for (i in rects.indices.reversed()) { // topmost preference
            val r = rects[i]
            // handles
            val corners = arrayOf(
                PointF(r.left, r.top), PointF(r.right, r.top),
                PointF(r.left, r.bottom), PointF(r.right, r.bottom)
            )
            for (c in corners) {
                if (RectF(c.x-HANDLE_SIZE, c.y-HANDLE_SIZE, c.x+HANDLE_SIZE, c.y+HANDLE_SIZE).contains(x, y))
                    return i to true
            }
            if (r.contains(x, y)) return i to false
        }
        return -1 to false
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val (idx, isHandle) = hitTest(event.x, event.y)
                activeIdx = idx
                mode = if (isHandle) Mode.RESIZE else if (idx != -1) Mode.MOVE else Mode.NONE
                downX = event.x; downY = event.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (activeIdx != -1) {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    val r = rects[activeIdx]
                    when (mode) {
                        Mode.MOVE -> {
                            r.offset(dx, dy)
                        }
                        Mode.RESIZE -> {
                            // resize from nearest corner (decide by which corner is closer to down point)
                            val leftDist = kotlin.math.hypot((downX - r.left).toDouble(), (downY - r.top).toDouble())
                            val rightDist = kotlin.math.hypot((downX - r.right).toDouble(), (downY - r.bottom).toDouble())
                            if (leftDist < rightDist) { r.left += dx; r.top += dy }
                            else { r.right += dx; r.bottom += dy }
                        }
                        else -> {}
                    }
                    constrainRect(r)
                    downX = event.x; downY = event.y
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeIdx = -1; mode = Mode.NONE
            }
        }
        return true
    }

    private fun constrainRect(r: RectF) {
        val w = width.toFloat(); val h = height.toFloat()
        r.left = max(0f, min(r.left, w-10f))
        r.top = max(0f, min(r.top, h-10f))
        r.right = max(r.left+10f, min(r.right, w))
        r.bottom = max(r.top+10f, min(r.bottom, h))
    }

    fun saveToPrefs() {
        val p = context.getSharedPreferences("roi", Context.MODE_PRIVATE).edit()
        fun put(name: String, rf: RectF) {
            p.putInt("${name}_x", rf.left.toInt())
            p.putInt("${name}_y", rf.top.toInt())
            p.putInt("${name}_w", (rf.width()).toInt())
            p.putInt("${name}_h", (rf.height()).toInt())
        }
        val keys = arrayOf("q","a1","a2","a3","a4")
        for (i in rects.indices) put(keys[i], rects[i])
        p.apply()
    }
}
