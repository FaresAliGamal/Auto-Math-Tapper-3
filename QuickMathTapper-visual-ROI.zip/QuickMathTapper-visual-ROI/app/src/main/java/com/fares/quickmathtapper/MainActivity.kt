package com.fares.quickmathtapper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.openOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            startService(Intent(this, OverlayConfigService::class.java))
            Toast.makeText(this, "تم فتح وضع ضبط المستطيلات", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.stopOverlay).setOnClickListener {
            stopService(Intent(this, OverlayConfigService::class.java))
            Toast.makeText(this, "تم الإيقاف", Toast.LENGTH_SHORT).show()
        }
    }
}
