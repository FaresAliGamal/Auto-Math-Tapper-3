package com.fares.quickmathtapper

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

object ScreenCapturer {
    private var mediaProjection: MediaProjection? = null
    private var width = 0
    private var height = 0
    private var density = 0
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null

    fun isReady() = mediaProjection != null

    fun requestCapture(ctx: Context) {
        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = Intent(ctx, ScreenCaptureActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        intent.putExtra("capIntent", mpm.createScreenCaptureIntent())
        ctx.startActivity(intent)
    }

    fun setProjection(mp: MediaProjection?, ctx: Context) {
        mediaProjection = mp
        if (mp != null) {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val dm = DisplayMetrics()
            wm.defaultDisplay.getMetrics(dm)
            width = dm.widthPixels
            height = dm.heightPixels
            density = dm.densityDpi
        }
    }

    fun captureOnce(ctx: Context, onBitmap: (Bitmap?)->Unit) {
        val mp = mediaProjection ?: run { onBitmap(null); return }
        if (reader == null) {
            reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
            vd = mp.createVirtualDisplay("qmt_cap", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY, reader!!.surface, null, null)
        }

        Handler(Looper.getMainLooper()).postDelayed({
            try {
                val img = reader!!.acquireLatestImage()
                if (img == null) { onBitmap(null); return@postDelayed }
                val plane = img.planes[0]
                val buf = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(buf)
                img.close()
                val cropped = Bitmap.createBitmap(bmp, 0, 0, width, height)
                onBitmap(cropped)
            } catch (e: Exception) {
                onBitmap(null)
            }
        }, 120)
    }

    fun release() {
        vd?.release(); vd = null
        reader?.close(); reader = null
        mediaProjection?.stop(); mediaProjection = null
    }
}
