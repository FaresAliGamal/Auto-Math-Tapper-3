package com.fares.quickmathtapper

import android.app.*
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

class OverlayConfigService : Service() {

    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var editor: RectEditorView

    override fun onBind(intent: android.content.Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START

        root = FrameLayout(this)
        editor = RectEditorView(this)
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xAA000000.toInt())
            val save = Button(context).apply {
                text = getString(R.string.save)
                setOnClickListener { editor.saveToPrefs() }
            }
            val start = Button(context).apply {
                text = getString(R.string.begin_solve)
                setOnClickListener {
                    // Save then start loop
                    editor.saveToPrefs()
                    AutoMathAccessibilityService.instance?.startAutoLoop(1000L)
                }
            }
            val hint = TextView(context).apply {
                text = "اسحب وحرك/كبر المستطيلات، ثم اضغط ابدأ الحل"
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(16, 16, 16, 16)
            }
            addView(save)
            addView(start)
            addView(hint)
        }

        root!!.addView(editor, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val tbParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT)
        root!!.addView(toolbar, tbParams)

        wm.addView(root, lp)

        // Foreground
        val channelId = "qmt_cfg"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "QuickMathTapper", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("ضبط مستطيلات QuickMathTapper")
            .setContentText("حرّك المقاسات ثم ابدأ الحل")
            .build()
        startForeground(2, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        root?.let { wm.removeView(it) }
    }
}
