package com.fares.quickmathtapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.RequiresApi
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class AutoMathAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoMathAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var looping = false
    private var intervalMs = 1000L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d("QMT", "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startAutoLoop(interval: Long = 1000L) {
        intervalMs = interval
        if (looping) return
        looping = true
        tick()
    }

    fun stopAutoLoop() {
        looping = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun tick() {
        if (!looping) return
        runOnce(this)
        handler.postDelayed({ tick() }, intervalMs)
    }

    fun runOnce(ctx: android.content.Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            takeAndProcessScreenshotApi33()
        } else {
            if (!ScreenCapturer.isReady()) {
                ScreenCapturer.requestCapture(this)
                return
            }
            ScreenCapturer.captureOnce(this) { bmp ->
                if (bmp != null) processBitmap(bmp) else Log.e("QMT","MediaProjection capture failed")
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    private fun takeAndProcessScreenshotApi33() {
        val exec = mainExecutor
        this.takeScreenshot(AccessibilityService.SCREENSHOT_REQUEST_CURRENT_DISPLAY, exec) { res ->
            try {
                val hb = res.hardwareBuffer
                val cs = res.colorSpace
                val bmp = Bitmap.wrapHardwareBuffer(hb, cs)!!.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                processBitmap(bmp)
            } catch (e: Exception) {
                Log.e("QMT", "screenshot failed: ${e.message}")
            }
        }
    }

    private fun getRect(name: String): Rect {
        val p = getSharedPreferences("roi", MODE_PRIVATE)
        val x = p.getInt("${name}_x", 0)
        val y = p.getInt("${name}_y", 0)
        val w = p.getInt("${name}_w", 100)
        val h = p.getInt("${name}_h", 60)
        return Rect(x, y, x + w, y + h)
    }

    private fun crop(src: Bitmap, r: Rect): Bitmap {
        val lx = max(0, min(r.left, src.width - 1))
        val ty = max(0, min(r.top, src.height - 1))
        val rx = max(lx + 1, min(r.right, src.width))
        val by = max(ty + 1, min(r.bottom, src.height))
        return Bitmap.createBitmap(src, lx, ty, rx - lx, by - ty)
    }

    private fun rectCenter(r: Rect): android.graphics.PointF {
        return android.graphics.PointF((r.left + r.right) / 2f, (r.top + r.bottom) / 2f)
    }

    private fun parseExpression(s: String): Double? {
        val clean = s.replace("=", " ").replace("?", " ")
        val regex = Regex("(-?\d+(?:\.\d+)?)\s*([+\-×x*/÷])\s*(-?\d+(?:\.\d+)?)")
        val m = regex.find(clean) ?: return null
        val a = m.groupValues[1].toDouble()
        val op = m.groupValues[2]
        val b = m.groupValues[3].toDouble()
        return when (op) {
            "+", "＋" -> a + b
            "-", "−" -> a - b
            "×", "x", "*", "⋅" -> a * b
            "÷", "/" -> if (b != 0.0) a / b else null
            else -> null
        }
    }

    private fun parseNumber(s: String): Double? {
        val m = Regex("-?\d+(?:\.\d+)?").find(s) ?: return null
        return m.value.toDoubleOrNull()
    }

    private fun ocr(bmp: Bitmap, onDone: (String)->Unit) {
        val img = InputImage.fromBitmap(bmp, 0)
        TextRecognition.getClient()
            .process(img)
            .addOnSuccessListener { v -> onDone(v.text) }
            .addOnFailureListener { _ -> onDone("") }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun processBitmap(full: Bitmap) {
        val qR = getRect("q")
        val aRs = arrayOf(getRect("a1"), getRect("a2"), getRect("a3"), getRect("a4"))
        val qBmp = crop(full, qR)
        val aBmps = aRs.map { crop(full, it) }

        ocr(qBmp) { qText ->
            val want = parseExpression(qText)
            if (want == null) {
                Log.e("QMT", "لم أفهم السؤال: $qText")
                return@ocr
            }
            val results = MutableList<Pair<Int, Double?>>(4) { 0 to null }
            var done = 0
            for ((i, b) in aBmps.withIndex()) {
                ocr(b) { t ->
                    results[i] = i to parseNumber(t)
                    done += 1
                    if (done == aBmps.size) {
                        var bestIdx = 0
                        var bestDiff = Double.MAX_VALUE
                        for ((idx, v) in results) {
                            val diff = if (v == null) Double.MAX_VALUE else abs(v - want)
                            if (diff < bestDiff) {
                                bestDiff = diff; bestIdx = idx
                            }
                        }
                        val center = rectCenter(aRs[bestIdx])
                        tap(center.x, center.y)
                        Log.d("QMT", "Q='$qText' -> $want ; tapped A${bestIdx+1} diff=$bestDiff")
                    }
                }
            }
        }
    }
}
